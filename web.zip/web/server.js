// server.js — egyszerű fájl-alapú "DB", session auth, posts
const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const bcrypt = require('bcrypt');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 4000;
const DATA_FILE = path.join(__dirname, 'data.json');

// init data file if missing
if (!fs.existsSync(DATA_FILE)) {
  fs.writeFileSync(DATA_FILE, JSON.stringify({ users: [], posts: [] }, null, 2));
}
function readData(){ return JSON.parse(fs.readFileSync(DATA_FILE)); }
function writeData(d){ fs.writeFileSync(DATA_FILE, JSON.stringify(d, null, 2)); }

app.use(bodyParser.json());
app.use(cors({
  origin: ['http://localhost:5173','http://localhost:3000','http://localhost:5500'], // add your frontend origin
  credentials: true
}));
app.use(session({
  secret: 'change_this_secret',
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, maxAge: 24*60*60*1000 } // 1 day
}));

// helper
function requireLogin(req, res, next){
  if (req.session && req.session.user) return next();
  return res.status(401).json({ error: 'Unauthorized' });
}

// register
app.post('/api/register', async (req,res) => {
  const { username, email, password } = req.body;
  if(!username || !email || !password) return res.status(400).json({ error: 'Missing fields' });

  const data = readData();
  if (data.users.find(u => u.username === username)) return res.status(400).json({ error: 'Username taken' });
  if (data.users.find(u => u.email === email)) return res.status(400).json({ error: 'Email taken' });

  const hash = await bcrypt.hash(password, 10);
  const id = (data.users.reduce((m,u)=>Math.max(m,u.id||0),0) || 0) + 1;
  const user = { id, username, email, password: hash };
  data.users.push(user);
  writeData(data);

  req.session.user = { id: user.id, username: user.username };
  res.json({ ok:true, user: { id: user.id, username: user.username } });
});

// login
app.post('/api/login', (req,res) => {
  const { username, password } = req.body;
  if(!username || !password) return res.status(400).json({ error: 'Missing fields' });

  const data = readData();
  const user = data.users.find(u => u.username === username);
  if (!user) return res.status(400).json({ error: 'Invalid credentials' });

  bcrypt.compare(password, user.password).then(match => {
    if (!match) return res.status(400).json({ error: 'Invalid credentials' });
    req.session.user = { id: user.id, username: user.username };
    res.json({ ok:true, user: req.session.user });
  }).catch(err => res.status(500).json({ error: 'Server error' }));
});

// logout
app.post('/api/logout', (req,res) => {
  req.session.destroy(err => {
    if(err) return res.status(500).json({ error: 'Logout failed' });
    res.clearCookie('connect.sid');
    res.json({ ok:true });
  });
});

// whoami
app.get('/api/me', (req,res) => {
  if(req.session && req.session.user) return res.json({ user: req.session.user });
  return res.json({ user: null });
});

// posts list
app.get('/api/posts', (req,res) => {
  const data = readData();
  // newest first
  const posts = (data.posts || []).slice().sort((a,b)=> new Date(b.created_at) - new Date(a.created_at));
  res.json({ posts });
});

// create post (only logged in)
app.post('/api/posts', requireLogin, (req,res) => {
  const { content } = req.body;
  if(!content || !content.trim()) return res.status(400).json({ error: 'Empty content' });

  const data = readData();
  const id = (data.posts.reduce((m,p)=>Math.max(m,p.id||0),0) || 0) + 1;
  const post = {
    id,
    user_id: req.session.user.id,
    username: req.session.user.username,
    content: content.trim(),
    created_at: new Date().toISOString()
  };
  data.posts.push(post);
  writeData(data);
  res.json({ ok:true, post });
});

app.listen(PORT, () => console.log(`Server listening on http://localhost:${PORT}`));
