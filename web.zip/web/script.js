// --- “Letöltés” gomb kattintás-effekt ---
const downloadButtons = document.querySelectorAll(".download-buttons a");
downloadButtons.forEach((btn) => {
  btn.addEventListener("click", (e) => {
    e.preventDefault();
    alert("🔪 A sötétség letöltése megkezdődött... (hamarosan elérhető)");
  });
});



// --- Kapcsolati űrlap “küldés” ---
const form = document.querySelector("form");
if (form) {
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    alert("🩸 Üzenet elküldve a sötétségbe...");
    form.reset();
  });
}

// --- BETÖLTŐ KÉPERNYŐ ---
window.addEventListener("load", () => {
  const loader = document.getElementById("loading-screen");
  setTimeout(() => {
    loader.classList.add("hidden");
  }, 3000); // 3 másodperc múlva tűnik el
});



// Modal elemek
const loginModal = document.getElementById("loginModal");
const loginButton = document.querySelector('a[href="#login"]');
const closeBtn = document.querySelector(".close-btn");

// Menü kattintás → modal megnyitása
loginButton.addEventListener("click", (e) => {
  e.preventDefault(); // ne ugorjon a #login részre
  loginModal.style.display = "flex";
});

// Bezáró gomb
closeBtn.addEventListener("click", () => {
  loginModal.style.display = "none";
});

// Háttérre kattintás → bezárás
window.addEventListener("click", (e) => {
  if (e.target === loginModal) {
    loginModal.style.display = "none";
  }
});

// --- MODAL PANELS ---
const loginPanel = document.getElementById("loginPanel");
const registerPanel = document.getElementById("registerPanel");
const forgotPanel = document.getElementById("forgotPanel");

// helper function panelek váltásához
function showPanel(panel) {
  loginPanel.classList.remove("active");
  registerPanel.classList.remove("active");
  forgotPanel.classList.remove("active");
  panel.classList.add("active");
}

// linkek
document.getElementById("openRegister").addEventListener("click", (e) => {
  e.preventDefault();
  showPanel(registerPanel);
});

document.getElementById("openForgot").addEventListener("click", (e) => {
  e.preventDefault();
  showPanel(forgotPanel);
});

document.getElementById("openLogin1").addEventListener("click", (e) => {
  e.preventDefault();
  showPanel(loginPanel);
});

document.getElementById("openLogin2").addEventListener("click", (e) => {
  e.preventDefault();
  showPanel(loginPanel);
});




// Forum + auth frontend (alap)
const API_BASE = 'http://localhost:4000/api';

// Egy egyszerű forum szekció HTML-t érdemes betenni a site-odra, pl. a HTML-ben:
// <section id="forum"><h2>Fórum</h2><div id="forum-area"></div></section>

async function api(path, opts = {}) {
  const res = await fetch(API_BASE + path, { credentials: 'include', headers: { 'Content-Type':'application/json' }, ...opts });
  return res.json();
}

// render posts
async function loadPosts() {
  const area = document.getElementById('forum-area');
  if(!area) return;
  area.innerHTML = '<p>Töltés…</p>';
  const data = await api('/posts', { method: 'GET' });
  const posts = data.posts || [];
  area.innerHTML = `
    <div id="post-form-wrap"></div>
    <div id="posts-list">${posts.map(p => `
      <div class="post">
        <div class="post-meta"><strong>${escapeHtml(p.username)}</strong> — ${new Date(p.created_at).toLocaleString()}</div>
        <div class="post-content">${escapeHtml(p.content)}</div>
      </div>
    `).join('')}</div>
  `;
  renderPostForm();
}

// escape helper
function escapeHtml(s){ return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

// show login / register forms + create-post form if logged in
async function renderPostForm(){
  const wrap = document.getElementById('post-form-wrap');
  if(!wrap) return;
  const me = await api('/me', { method: 'GET' });
  if(me.user){
    wrap.innerHTML = `
      <div>Bejelentkezve: <strong>${escapeHtml(me.user.username)}</strong> <button id="logoutBtn">Kijelentkezés</button></div>
      <form id="newPostForm">
        <textarea id="newPostContent" rows="3" placeholder="Írj valamit…"></textarea>
        <button type="submit">Posztolás</button>
      </form>
    `;
    document.getElementById('logoutBtn').addEventListener('click', async ()=>{
      await api('/logout', { method: 'POST' }); loadPosts();
    });
    document.getElementById('newPostForm').addEventListener('submit', async (e)=>{
      e.preventDefault();
      const content = document.getElementById('newPostContent').value;
      const res = await api('/posts', { method: 'POST', body: JSON.stringify({ content }) });
      if(res.ok) { document.getElementById('newPostContent').value = ''; loadPosts(); }
      else alert(res.error || 'Hiba a posztolásnál');
    });
  } else {
    wrap.innerHTML = `
      <div id="auth-forms">
        <form id="loginSmall" style="margin-bottom:8px;">
          <input id="loginUser" placeholder="Felhasználó" required />
          <input id="loginPass" type="password" placeholder="Jelszó" required />
          <button>Bejelentkezés</button>
        </form>
        <form id="regSmall">
          <input id="regUser" placeholder="Felhasználó" required />
          <input id="regEmail" placeholder="E-mail" required />
          <input id="regPass" type="password" placeholder="Jelszó" required />
          <button>Regisztráció</button>
        </form>
      </div>
    `;
    document.getElementById('loginSmall').addEventListener('submit', async (e)=>{
      e.preventDefault();
      const username = document.getElementById('loginUser').value;
      const password = document.getElementById('loginPass').value;
      const res = await api('/login', { method:'POST', body: JSON.stringify({ username, password }) });
      if(res.user) loadPosts(); else alert(res.error || 'Bejelentkezés sikertelen');
    });
    document.getElementById('regSmall').addEventListener('submit', async (e)=>{
      e.preventDefault();
      const username = document.getElementById('regUser').value;
      const email = document.getElementById('regEmail').value;
      const password = document.getElementById('regPass').value;
      const res = await api('/register', { method:'POST', body: JSON.stringify({ username, email, password }) });
      if(res.user) loadPosts(); else alert(res.error || 'Regisztráció sikertelen');
    });
  }
}

// init
document.addEventListener('DOMContentLoaded', ()=> {
  // ha nincs forum-area, adjuk hozzá automatikusan a lapodra egy section-t
  if(!document.getElementById('forum-area')) {
    const s = document.createElement('section');
    s.id = 'forum';
    s.innerHTML = '<h2>Fórum</h2><div id="forum-area"></div>';
    document.body.appendChild(s);
  }
  loadPosts();
});

function loadPosts() {
    const posts = JSON.parse(localStorage.getItem("forumPosts")) || [];
    const container = document.getElementById("posts");
    container.innerHTML = "";

    posts.forEach(post => {
        const div = document.createElement("div");
        div.className = "post";

        div.innerHTML = `
            <div class="post-author">${post.author}</div>
            <div class="post-date">${post.date}</div>
            <div class="post-text">${post.text}</div>
        `;

        container.appendChild(div);
    });
}

function addPost() {
    const author = document.getElementById("post-author").value.trim();
    const text = document.getElementById("post-text").value.trim();

    if (!author || !text) {
        alert("Tölts ki minden mezőt!");
        return;
    }

    const newPost = {
        author,
        text,
        date: new Date().toLocaleString("hu-HU")
    };

    const posts = JSON.parse(localStorage.getItem("forumPosts")) || [];
    posts.unshift(newPost);
    localStorage.setItem("forumPosts", JSON.stringify(posts));

    document.getElementById("post-author").value = "";
    document.getElementById("post-text").value = "";

    loadPosts();
}

window.onload = loadPosts;


